The python version used was python version 3.

Run the program on command line with python3 dv_algorithm.py topology.csv